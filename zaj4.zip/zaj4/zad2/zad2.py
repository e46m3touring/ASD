import time
from collections import deque
from datetime import datetime

class Notification:
    def __init__(self, content, ntype, priority):
        self.content = content  # Treść powiad
        self.ntype = ntype      # Typ powiad (info, warning, error)
        self.timestamp = time.time()  # Znacznik czasu powiad
        self.priority = priority  # Priorytet powiad

    def __repr__(self):
        readable_time = datetime.fromtimestamp(self.timestamp).strftime("%Y-%m-%d %H:%M:%S")
        return f"{self.ntype.upper()}: {self.content} (Priority: {self.priority}, Time: {readable_time})"

class NotificationSystem:
    def __init__(self, max_low_priority_notifications=5):
        self.queue = deque()  # Kolejka FIFO
        self.max_low_priority_notifications = max_low_priority_notifications  # Limit powiad o niskim prior
        self.pending_count = 0  # Liczba oczekujących powiad

    def add_notification(self, notification):
        """Dodaj powiadomienie do kolejki, uwzględniając priorytet"""
        if notification.priority == 'low' and self.count_low_priority_notifications() >= self.max_low_priority_notifications:
            self.remove_oldest_low_priority()
        
        if notification.priority == 'high':
            self.queue.appendleft(notification)  # Pilne powiad traf na pocz
        else:
            self.queue.append(notification)

        self.pending_count += 1

    def count_low_priority_notifications(self):
        """Zlicz liczbę powiadomień o niskim priorytecie w kolejce"""
        return sum(1 for n in self.queue if n.priority == 'low')

    def remove_oldest_low_priority(self):
        """Usuń najstarsze powiadomienie o najniższym priorytecie"""
        for notification in self.queue:
            if notification.priority == 'low':
                self.queue.remove(notification)
                self.pending_count -= 1
                break

    def show_notification(self):
        """Wyświetl powiadomienie (usuwanie powiadomienia z kolejki po wyświetleniu)"""
        if self.queue:
            notification = self.queue.popleft()
            self.pending_count -= 1
            print(f"Notification: {notification}")
        else:
            print("Brak powiadomień do wyświetlenia.")

    def show_all_notifications(self):
        """Wyświetl wszystkie powiadomienia (zachowując kolejność FIFO)"""
        while self.queue:
            self.show_notification()

# Przykład
notification_system = NotificationSystem(max_low_priority_notifications=3)

# Dodawanie powiad
notification_system.add_notification(Notification("Masz nowe zadanie!", "info", "low"))
notification_system.add_notification(Notification("Zbyt mało pamięci!", "warning", "high"))
notification_system.add_notification(Notification("Błąd aplikacji", "error", "high"))
notification_system.add_notification(Notification("Nowa wiadomość", "info", "low"))

# Wyświetlanie powiad
notification_system.show_notification()
notification_system.show_all_notifications()

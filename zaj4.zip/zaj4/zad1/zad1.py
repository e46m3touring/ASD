class ActionHistory:
    def __init__(self):
        self.actions = []  # Stos dla historii działań
        self.redo_stack = []  # Stos dla historii cofniętych działań

    def execute(self, action):
        """Wykonaj działanie i zapisz je w historii"""
        self.actions.append(action)
        self.redo_stack.clear()  # Wyczyść stos redo - nowe działanie  dodane

    def undo(self):
        """Cofnij ostatnie działanie"""
        if self.actions:
            last_action = self.actions.pop()
            self.redo_stack.append(last_action)
            print(f"Undo: {last_action}")
        else:
            print("Brak działań do cofnięcia.")

    def redo(self):
        """Ponownie wykonaj cofnięte działanie"""
        if self.redo_stack:
            last_undone_action = self.redo_stack.pop()
            self.actions.append(last_undone_action)
            print(f"Redo: {last_undone_action}")
        else:
            print("Brak działań do ponownego wykonania.")

    def delete(self):
        """Usuń ostatnie działanie z historii"""
        if self.actions:
            last_action = self.actions.pop()
            print(f"Deleted: {last_action}")
        else:
            print("Brak działań do usunięcia.")

# Przykład użycie
history = ActionHistory()

# Wykonanie działań
history.execute("Rysowanie prostokąta")
history.execute("Rysowanie okręgu")
history.execute("Dodanie tekstu")

# Cofnięcie ostatniego działania
history.undo()

# Ponowne wykonanie cofniętego działania
history.redo()

# Usunięcie ostatniego działania
history.delete()

# Próba cofnięcia po usunięciu
history.undo()

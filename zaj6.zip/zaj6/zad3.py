import random
from datetime import datetime, timedelta
from collections import defaultdict

def visit_location(locations_dict, coordinates, visit_time=None):
    """
    Funkcja zapisuje wszystkie czasy odwiedzin dla podanych współrzędnych (lokalizacji).
    Jeśli czas nie jest podany, używa bieżącego czasu.
    """
    if visit_time is None:
        visit_time = datetime.now()
    
    locations_dict[coordinates].append(visit_time)

def visits_on_day(locations_dict, search_date):
    """
    Funkcja przeszukuje hashmapę i zwraca lokalizacje odwiedzone danego dnia.
    """
    visited_locations = []
    for coords, times in locations_dict.items():
        for visit_time in times:
            if visit_time.date() == search_date.date():
                visited_locations.append(coords)
                break  
    return visited_locations

locations = [(round(random.uniform(-90, 90), 2), round(random.uniform(-180, 180), 2)) for _ in range(10)]

locations_dict = defaultdict(list)

visit_count = 50
start_time = datetime(2025, 1, 1, 12, 0)

for i in range(visit_count):
    location = random.choice(locations)
    
    random_time_delta = timedelta(days=random.randint(0, 3), hours=random.choice([8, 12]))
    visit_time = start_time + random_time_delta
    
    visit_location(locations_dict, location, visit_time)
    
    start_time = visit_time

search_date = datetime(2025, 1, 2)

visited_locations_today = visits_on_day(locations_dict, search_date)

print(f"Daty wizyt:")
for coords, times in locations_dict.items():
    for visit_time in times:
        print(f"{coords} odwiedzone w {visit_time}")

print(f"\nLokalizacje odwiedzone {search_date.date()}:")
if visited_locations_today:
    for loc in visited_locations_today:
        print(loc)
else:
    print("Brak wizyt tego dnia.")


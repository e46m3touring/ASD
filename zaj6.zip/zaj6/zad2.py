import re
from collections import defaultdict

def count_words_by_letter(text):
    """
    Funkcja zlicza liczbę słów zaczynających się na każdą literę w podanym tekście.
    Ignoruje wielkość liter oraz interpunkcję.
    """
    text = re.sub(r'[^\w\s]', '', text).lower()

    letter_count = defaultdict(int)

    words = re.findall(r'\b[a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+\b', text)

    for word in words:
        first_letter = word[0]
        letter_count[first_letter] += 1

    sorted_counts = dict(sorted(letter_count.items(), key=lambda item: item[1], reverse=True))

    return sorted_counts

# Przykładowy tekst (600-700 słów)
text = """
    W tym zadaniu stworzymy prostą funkcję, która zliczy liczbę słów w tekście,
    zaczynających się na każdą literę. Tekst ten będzie zawierał kilka przykładów
    słów zaczynających się na różne litery. Zastosujemy odpowiednie techniki
    przetwarzania tekstu, aby osiągnąć zamierzony cel. Można zastosować wyrażenia
    regularne, które pomogą znaleźć wszystkie słowa, zignorować interpunkcję i wielkość liter.
    Następnie zliczymy, ile słów zaczyna się na daną literę w całym tekście. Zrobimy to
    za pomocą hashmapy i wyświetlimy wynik w kolejności od najwięcej do najmniej.
    """
    
result = count_words_by_letter(text)

print(result)

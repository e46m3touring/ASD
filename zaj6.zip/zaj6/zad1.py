class HashMap:
    def __init__(self, table_size, hash_function):
        self.table_size = table_size
        self.table = [[] for _ in range(table_size)] 
        self.hash_function = hash_function

    def insert(self, key, value):
        index = self.hash_function(key, self.table_size)
        for pair in self.table[index]:
            if pair[0] == key:
                pair[1] = value  
                return
        self.table[index].append((key, value))  

    def get(self, key):
        index = self.hash_function(key, self.table_size)
        for pair in self.table[index]:
            if pair[0] == key:
                return pair[1]  
        return None  

def simple_hash(string, table_size):
    """Prosta funkcja haszująca: sumuje kody ASCII znaków i stosuje modulo."""
    return sum(ord(char) for char in string) % table_size

def horner_hash(string, table_size):
    """Funkcja Hornera: używa mnożenia przez stałą i dodaje wartości ASCII."""
    hash_value = 0
    for char in string:
        hash_value = (hash_value * 31 + ord(char)) % table_size
    return hash_value

def fnv1a_hash(string, table_size):
    """Funkcja FNV-1a: wykorzystuje XOR i mnożenie przez stałą."""
    hash_value = 2166136261
    for char in string:
        hash_value ^= ord(char)
        hash_value *= 16777619
        hash_value = hash_value & 0xFFFFFFFF  
    return hash_value % table_size

def djb2_hash(string, table_size):
    """Funkcja DJB2: mnoży przez 33 i dodaje wartości ASCII, z ograniczeniem zakresu."""
    hash_value = 5381
    for char in string:
        hash_value = ((hash_value * 33) ^ ord(char)) & 0xFFFFFFFF
    return hash_value % table_size

strings = ["apple", "banana", "grape", "orange", "carrot", "melon", "kiwi", "mango", "pear", "peach"]
table_size = 31  

for hash_func in [simple_hash, horner_hash, fnv1a_hash, djb2_hash]:
    print(f"Testing {hash_func.__name__}:")
    hash_map = HashMap(table_size, hash_func)
    for string in strings:
        hash_map.insert(string, f"Value for {string}")
    
    for i, value in enumerate(hash_map.table):
        print(f"Index {i}: {value}")
    print("-" * 40)
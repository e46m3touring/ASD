# Pętle while

# Prosta pętla while
x = 0
while x < 5:
    print("x wynosi:", x)
    x += 1

#  While + break
x = 0
while x < 10:
    print("x:", x)
    if x == 5:
        print("Przerywanie pętli")
        break
    x += 1

# While + continue
x = 0
while x < 5:
    x += 1
    if x == 3:
        print("Pomijanie wartości 3")
        continue
    print("x wynosi:", x)

# While + else
x = 0
while x < 3:
    print("Iteracja:", x)
    x += 1
else:
    print("Pętla zakończona poprawnie")

# Nieskończ, zatrz po 5 lit
x = 0
while True:
    print("Nieskończona pętla, iteracja:", x)
    x += 1
    if x >= 5:
        print("Przerywanie pętli")
        break
    
    

# Stringi

# Definiowanie 
napis1 = "Witaj w Pythonie!"
napis2 = 'To jest string w cudzysłowie'
napis3 = """To jest 
string wieloliniowy"""

print(napis1)
print(napis2)
print(napis3)

# Łączenie 
tekst1 = "Hello"
tekst2 = "World"
zlaczenie = tekst1 + " " + tekst2
print("Połączone stringi:", zlaczenie)

# Powielanie 
powielony = "Python " * 3
print("Powielony string:", powielony)

# Dostęp do znaków
slowo = "Python"
print("Pierwszy znak:", slowo[0])
print("Ostatni znak:", slowo[-1])

# Wycin frag string
print("Podciąg:", slowo[1:4])

# Długość 
print("Długość napisu:", len(slowo))

# Metody 
print("Wielkie litery:", slowo.upper())
print("Małe litery:", slowo.lower())
print("Zamiana liter P na X:", slowo.replace("P", "X"))
print("Podział stringa:", "a,b,c".split(","))

# Czy string ma fragment
print("Czy 'Py' jest w 'Python'?", "Py" in slowo)


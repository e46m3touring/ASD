# Składnia 

# Komentarz

"""
komentarz
wieloliniowy
"""

print("Witaj w Pythonie!")

# Wcięcia zamiast nawiasów klamrowych
if True:
    print("Warunek prawdziwy")  
else:
    print("Warunek fałszywy")

# Deklaracja 
a = 10     #  całkowita
b = 5.5    #  zmiennoprzecinkowa
c = "Python"  # ciąg 

print("a:", a, "b:", b, "c:", c)

# Definiowanie funkcji
def powitanie(imie):
    return "Cześć, " + imie + "!"

print(powitanie("Alex"))

# For
dla_lista = [1, 2, 3, 4, 5]
for liczba in dla_lista:
    print("Liczba:", liczba)

# While
x = 0
while x < 3:
    print("x wynosi:", x)
    x += 1
    
    

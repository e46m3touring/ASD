# Warunkowe if-else

# Sprawd waru
a = 10
b = 20

if a > b:
    print("a jest większe od b")
elif a == b:
    print("a jest równe b")
else:
    print("a jest mniejsze od b")

# Wiele warunków
x = 50
y = 100

if x > 0 and y > 0:
    print("Obie liczby są dodatnie")

# Warunkowa + or
if x < 0 or y > 50:
    print("Jedna z liczb spełnia warunek")

# Operator warunkowy w jednej linii
wynik = "Tak" if a < b else "Nie"
print("Czy a jest mniejsze od b?", wynik)

# Zagnieżdżone instrukcje warunkowe
liczba = 7
if liczba > 0:
    print("Liczba jest dodatnia")
    if liczba % 2 == 0:
        print("Liczba jest parzysta")
    else:
        print("Liczba jest nieparzysta")
        
        

print("Hello, World!")

# Zmien
message = "Hello, Python!"
print(message)

# Pods funk
def greet():
    return "Hello from a function!"

print(greet())

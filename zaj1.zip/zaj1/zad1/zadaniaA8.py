# Funkcje 

# Definiowanie 
def powitanie():
    print("Witaj w Pythonie!")

powitanie()

# Funk z argum
def dodaj(a, b):
    return a + b

wynik = dodaj(5, 3)
print("Suma:", wynik)

# Funk z wart domysl
def powitanie_imie(imie="Arek"):
    print(f"Witaj, {imie}!")

powitanie_imie("Alex")
powitanie_imie()

# Funkcja zwrac > niż 1 wart
def operacje(a, b):
    suma = a + b
    roznica = a - b
    return suma, roznica

s, r = operacje(10, 4)
print("Suma:", s, "Różnica:", r)

# Argum pozyc i nazwan
def przedstaw_sie(imie, wiek):
    print(f"Cześć, jestem {imie} i mam {wiek} lat.")

przedstaw_sie("Sofi", 19)
przedstaw_sie(wiek=20, imie="Mars")

# Rekurencyjna
def silnia(n):
    if n == 0:
        return 1
    return n * silnia(n - 1)

print("Silnia 5:", silnia(5))


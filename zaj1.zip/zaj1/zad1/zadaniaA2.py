

print("Hello, Python Interpreter!")


a = 5
b = 3
print("Suma:", a + b)
print("Różnica:", a - b)
print("Iloczyn:", a * b)
print("Iloraz:", a / b)

# Uż zmien
name = "Python"
version = 3.10
print("Język:", name, "Wersja:", version)

# Funkcja
def square(num):
    return num * num

print("Kwadrat liczby 4:", square(4))


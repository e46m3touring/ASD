# Zmienne

# Deklaracja zmiennych
liczba_calkowita = 10  # całkowita
liczba_zmiennoprzecinkowa = 5.5  # zmiennoprzecinkowa
ciag_znakow = "Python"  # ciąg znkw
wartosc_logiczna = True  # zmien logiczna
lista = [1, 2, 3, 4, 5]  # lista
tupla = (10, 20, 30)  # krotka
slownik = {"klucz": "wartość", "wiek": 25}  # słownik

# Wypisanie wartości zmiennych
print("Liczba całkowita:", liczba_calkowita)
print("Liczba zmiennoprzecinkowa:", liczba_zmiennoprzecinkowa)
print("Ciąg znaków:", ciag_znakow)
print("Wartość logiczna:", wartosc_logiczna)
print("Lista:", lista)
print("Krotka:", tupla)
print("Słownik:", slownik)

# Dynamiczne przypisanie typu
dynamiczna_zmienna = 100
print("Dynamiczna zmienna (przed zmianą):", dynamiczna_zmienna)
dynamiczna_zmienna = "Teraz jestem stringiem"
print("Dynamiczna zmienna (po zmianie):", dynamiczna_zmienna)

# Przypisanie wielu wartości na raz
a, b, c = 10, 20, "Python"
print("a:", a, "b:", b, "c:", c)

# Zmienne globalne i lokalne
globalna = "Jestem globalna"

def funkcja():
    lokalna = "Jestem lokalna"
    print("Wewnątrz funkcji:", lokalna)
    print("Dostęp do globalnej:", globalna)

funkcja()
print("Na zewnątrz funkcji, globalna:", globalna)


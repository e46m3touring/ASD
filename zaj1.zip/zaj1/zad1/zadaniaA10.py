# Praca z listami

# Tworzenie 
lista = [1, 2, 3, 4, 5]
print("Lista:", lista)

# + elementy
dodana_lista = lista + [6, 7]
print("Lista po dodaniu elementów:", dodana_lista)

lista.append(8)
print("Lista po użyciu append:", lista)

# Usuw elem
lista.remove(3)  # usun 1 poj 3
print("Lista po usunięciu 3:", lista)

# Indeksowanie i wycinanie
print("Pierwszy element:", lista[0])
print("Ostatni element:", lista[-1])
print("Podlista od indeksu 1 do 3:", lista[1:4])

# Długość
print("Długość listy:", len(lista))

# Sortowanie
lista.sort()
print("Posortowana lista:", lista)

# Odwr kolej
lista.reverse()
print("Odwrócona lista:", lista)

# Iteracja po liście
for element in lista:
    print("Element:", element)

# Sprawdz obecności elementu
print("Czy 5 jest w liście?", 5 in lista)

# Kopiowanie 
kopia_listy = lista[:]
print("Kopia listy:", kopia_listy)


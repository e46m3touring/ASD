# Pętle for w 

# Iteracja po liście
lista = [1, 2, 3, 4, 5]
for element in lista:
    print("Element listy:", element)

# Iteracja po zakresie liczb
for i in range(5):  
    print("Wartość i:", i)

# Iteracja po zakresie z krokiem
for i in range(1, 10, 2):  
    print("Liczba z krokiem 2:", i)

# Iteracja po stringu
napis = "Python"
for litera in napis:
    print("Litera:", litera)

# Iteracja po słowniku
dane = {"imie": "Alex", "wiek": 24, "miasto": "Poznan"}
for klucz, wartosc in dane.items():
    print(f"{klucz}: {wartosc}")

# Zagnieżdżona pętla for
for i in range(3):
    for j in range(2):
        print(f"i={i}, j={j}")

# For + else
for i in range(3):
    print("Iteracja:", i)
else:
    print("Pętla zakończona")
    

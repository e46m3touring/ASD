# pierwiastek sześcienny liczby

def cube_checker(volume, side):
    if volume <= 0 or side <= 0:
        return False
    return volume == side ** 3

# Przykładowe testy
print(cube_checker(27, 3))  
print(cube_checker(16, 4))  
print(cube_checker(0, 0))   


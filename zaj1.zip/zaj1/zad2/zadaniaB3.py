# litera-symbol 1337 :)

def to_leet_speak(string):
    mapping = {'A': '4', 'B': '8', 'C': '<', 'E': '3', 'G': '6', 'H': '#', 'I': '1', 'L': '|', 'O': '0', 'S': '5', 'T': '7', 'Z': '2'}
    return ''.join(mapping.get(char, char) for char in string.upper())

# Przykładowe testy
print(to_leet_speak("LEET"))  
print(to_leet_speak("HELLO WORLD"))  
print(to_leet_speak("CODE"))

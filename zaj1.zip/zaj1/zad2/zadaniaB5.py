# litery w stringu wystep dokładnie dwa razy

def count_letters(string):
    counts = {}
    for char in string:
        counts[char] = counts.get(char, 0) + 1
    return sum(1 for char, count in counts.items() if count == 2)

# Przykładowe testy
print(count_letters("aabbcde"))  
print(count_letters("aabBcde"))   
print(count_letters("indivisibility"))  
print(count_letters("aA11"))   
print(count_letters("ABBA"))

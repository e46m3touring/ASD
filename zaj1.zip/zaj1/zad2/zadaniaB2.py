# czy english istnieje

def sp_eng(sentence):
    return "english" in sentence.lower()

# Przykładowe testy
print(sp_eng("We speak English here.")) 
print(sp_eng("This is a test sentence."))  
print(sp_eng("english"))

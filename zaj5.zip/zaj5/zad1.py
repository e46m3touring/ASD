def insertion_sort(arr, start, end):
    comparisons = 0
    for i in range(start + 1, end):
        key = arr[i]
        j = i - 1
        while j >= start and arr[j] > key:
            comparisons += 1
            arr[j + 1] = arr[j]
            j -= 1
        comparisons += 1 if j >= start else 0  # końcowe porównanie false
        arr[j + 1] = key
    return comparisons
 
def merge(left, right):
    result = []
    comparisons = 0
    i = j = 0
 
    while i < len(left) and j < len(right):
        comparisons += 1
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
 
    result.extend(left[i:])
    result.extend(right[j:])
    return result, comparisons
 
def merge_sort_with_count(runs):
    total_comparisons = 0
    while len(runs) > 1:
        new_runs = []
        for i in range(0, len(runs), 2):
            if i + 1 < len(runs):
                merged, comp = merge(runs[i], runs[i+1])
                total_comparisons += comp
                new_runs.append(merged)
            else:
                new_runs.append(runs[i])
        runs = new_runs
    return runs[0] if runs else [], total_comparisons
 
def hybrid_sort(arr, run_size):
    n = len(arr)
    total_comparisons = 0
    runs = []
 
    for start in range(0, n, run_size):
        end = min(start + run_size, n)
        total_comparisons += insertion_sort(arr, start, end)
        runs.append(arr[start:end])
 
    sorted_arr, merge_comparisons = merge_sort_with_count(runs)
    total_comparisons += merge_comparisons
    return sorted_arr, total_comparisons
 
# Testy:
import random
 
def test_scenarios():
    sizes = [10, 20, 50]
    run_sizes = [2, 5, 10]
    types = {
        "sorted": lambda n: list(range(n)),
        "reverse": lambda n: list(range(n, 0, -1)),
        "random": lambda n: random.sample(range(n * 2), n),
        "almost_sorted": lambda n: list(range(n))[:-2] + [n-1, n-2],
    }
 
    for n in sizes:
        for run in run_sizes:
            print(f"\nArray size: {n}, Run size: {run}")
            for name, generator in types.items():
                arr = generator(n)
                arr_copy = arr.copy()
                sorted_arr, comparisons = hybrid_sort(arr_copy, run)
                print(f"  {name:15} -> comparisons: {comparisons}")
 
test_scenarios()
class Node:
    def __init__(self, is_leaf=False):
        self.keys = []
        self.values = [] if is_leaf else None
        self.children = [] if not is_leaf else None
        self.next = None  # wskaźnik do kolejnego liścia
        self.parent = None  # wskaźnik do rodzica
 
class BPlusTree:
    def __init__(self, max_leaf_size=3):
        self.root = Node(is_leaf=True)
        self.max_leaf_size = max_leaf_size
        self.nick_map = {}  # nick -> score
        self.comparisons = 0
 
    def add_player(self, nick, score):
        self.comparisons = 0
        if nick in self.nick_map:
            self.comparisons += 1
            return self.update_score(nick, score)
 
        self.nick_map[nick] = score
        node = self.root
 
        while node.children:
            i = 0
            while i < len(node.keys) and score >= node.keys[i]:
                self.comparisons += 1
                i += 1
            node = node.children[i]
 
        i = 0
        while i < len(node.keys) and score > node.keys[i]:
            self.comparisons += 1
            i += 1
 
        if i < len(node.keys) and node.keys[i] == score:
            self.comparisons += 1
            node.values[i].append(nick)
        else:
            node.keys.insert(i, score)
            node.values.insert(i, [nick])
 
        if len(node.keys) > self.max_leaf_size:
            self._split_leaf(node)
 
    def _split_leaf(self, node):
        mid = len(node.keys) // 2
        new_leaf = Node(is_leaf=True)
        new_leaf.keys = node.keys[mid:]
        new_leaf.values = node.values[mid:]
        node.keys = node.keys[:mid]
        node.values = node.values[:mid]
        new_leaf.next = node.next
        node.next = new_leaf
 
        if node.parent is None:
            new_root = Node()
            new_root.keys = [new_leaf.keys[0]]
            new_root.children = [node, new_leaf]
            node.parent = new_root
            new_leaf.parent = new_root
            self.root = new_root
        else:
            self._insert_into_parent(node.parent, new_leaf.keys[0], new_leaf)
 
    def _insert_into_parent(self, parent, key, new_node):
        i = 0
        while i < len(parent.keys) and key > parent.keys[i]:
            i += 1
        parent.keys.insert(i, key)
        parent.children.insert(i + 1, new_node)
        new_node.parent = parent
        if len(parent.keys) > self.max_leaf_size:
            self._split_internal(parent)
 
    def _split_internal(self, node):
        mid = len(node.keys) // 2
        new_internal = Node()
        new_internal.keys = node.keys[mid + 1:]
        new_internal.children = node.children[mid + 1:]
 
        for child in new_internal.children:
            child.parent = new_internal
 
        node.keys = node.keys[:mid]
        node.children = node.children[:mid + 1]
 
        if node.parent is None:
            new_root = Node()
            new_root.keys = [node.keys[mid]]
            new_root.children = [node, new_internal]
            node.parent = new_root
            new_internal.parent = new_root
            self.root = new_root
        else:
            self._insert_into_parent(node.parent, node.keys[mid], new_internal)
 
    def update_score(self, nick, new_score):
        self.comparisons = 0
        if nick not in self.nick_map:
            self.comparisons += 1
            return
 
        old_score = self.nick_map[nick]
        self.remove_player(nick)
        self.add_player(nick, new_score)
 
    def remove_player(self, nick):
        self.comparisons = 0
        if nick not in self.nick_map:
            self.comparisons += 1
            return
 
        score = self.nick_map[nick]
        node = self.root
 
        while node.children:
            i = 0
            while i < len(node.keys) and score >= node.keys[i]:
                self.comparisons += 1
                i += 1
            node = node.children[i]
 
        for i in range(len(node.keys)):
            self.comparisons += 1
            if node.keys[i] == score:
                if nick in node.values[i]:
                    self.comparisons += 1
                    node.values[i].remove(nick)
                    if not node.values[i]:
                        node.keys.pop(i)
                        node.values.pop(i)
                    break
        del self.nick_map[nick]
 
    def get_score(self, nick):
        self.comparisons = 0
        return self.nick_map.get(nick, None)
 
    def get_players_in_range(self, min_score, max_score):
        self.comparisons = 0
        node = self.root
        while node.children:
            node = node.children[0]
 
        result = []
        while node:
            for i in range(len(node.keys)):
                self.comparisons += 1
                if min_score <= node.keys[i] <= max_score:
                    result.extend(node.values[i])
                elif node.keys[i] > max_score:
                    return result
            node = node.next
        return result
 
    def get_best_player(self):
        self.comparisons = 0
        node = self.root
        while node.children:
            node = node.children[-1]
        return (node.values[-1][0], node.keys[-1]) if node.keys else None
 
    def get_worst_player(self):
        self.comparisons = 0
        node = self.root
        while node.children:
            node = node.children[0]
        return (node.values[0][0], node.keys[0]) if node.keys else None
 
# Testowanie
tree = BPlusTree()
 
tree.add_player("Alice", 150)
tree.add_player("Bob", 100)
tree.add_player("Charlie", 200)
tree.add_player("Daisy", 150)
 
print("Best player:", tree.get_best_player(), "| Comparisons:", tree.comparisons)
print("Worst player:", tree.get_worst_player(), "| Comparisons:", tree.comparisons)
print("Range 120-160:", tree.get_players_in_range(120, 160), "| Comparisons:", tree.comparisons)
 
tree.update_score("Bob", 180)
print("Updated Bob. Score now:", tree.get_score("Bob"), "| Comparisons:", tree.comparisons)
 
tree.remove_player("Daisy")
print("Removed Daisy. Range 100-200:", tree.get_players_in_range(100, 200), "| Comparisons:", tree.comparisons)
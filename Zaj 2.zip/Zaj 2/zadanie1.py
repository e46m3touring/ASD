
def constant_algorithm(counter):
    #Algorytm o złożoności O(1) – wykonuje stałą liczbę operacji.
    counter[0] += 1  # Jedna operacja
    return #Wynik O(1)"


def linear_algorithm(n, counter):
    #Algorytm o złożoności O(n) – wykonuje pętlę, iterując n razy.
    for i in range(n):
        counter[0] += 1  # Operacja dla każdej iteracji
    return #Wynik O(n)"


def quadratic_algorithm(n, counter):
    #Algorytm o złożoności O(n²) – dwie zagnieżdżone pętle, każda iteruje n razy.
    for i in range(n):
        for j in range(n):
            counter[0] += 1  # Operacja wewnątrz zagnieżdżonych pętli
    return #Wynik O(n²)"


def exponential_algorithm(n, counter):
    #Przykładowy algorytm rekurencyjny o złożoności O(2^n).
    #Dla n <= 0 wykonuje jedną operację, a dla n > 0 wywołuje samego siebie dwukrotnie.
    if n <= 0:
        counter[0] += 1
        return 1
    else:
        counter[0] += 1
        left = exponential_algorithm(n - 1, counter)
        right = exponential_algorithm(n - 1, counter)
        return left + right


def test_algorithms():
    #Funkcja testująca wszystkie algorytmy dla różnych rozmiarów danych.
    #Dla algorytmów o wysokiej złożoności (O(n²) i O(2^n)) testujemy tylko niewielkie wartości,aby uniknąć długiego czasu wykonania.
    # Testujemy dla "małej", "średniej" i "dużej" wielkości danych
    sizes = [100, 10000, 1000000]
    
    print("Test algorytmu O(1):")
    for n in sizes:
        counter = [0]  # Używamy listy, aby mieć zmienny licznik
        result = constant_algorithm(counter)
        print(f"Dla n = {n}: {result}, wykonano kroków = {counter[0]}")
    
    print("\nTest algorytmu O(n):")
    for n in sizes:
        counter = [0]
        result = linear_algorithm(n, counter)
        print(f"Dla n = {n}: {result}, wykonano kroków = {counter[0]}")
    
    print("\nTest algorytmu O(n²):")
    for n in sizes:
        if n > 100:
            # Ze względu na gwałtowny wzrost liczby operacji, testujemy tylko dla niewielkich n
            print(f"Dla n = {n}: pomijam test (zbyt duża liczba operacji)")
        else:
            counter = [0]
            result = quadratic_algorithm(n, counter)
            print(f"Dla n = {n}: {result}, wykonano kroków = {counter[0]}")
    
    print("\nTest algorytmu O(2ⁿ) (wykładniczy):")
    # Wybieramy bardzo małe wartości n, aby uniknąć problemów z czasem wykonania
    exponential_sizes = [5, 6]
    for n in exponential_sizes:
        counter = [0]
        result = exponential_algorithm(n, counter)
        print(f"Dla n = {n}: wynik = {result}, wykonano kroków = {counter[0]}")
# Uruchomienie testów
test_algorithms()

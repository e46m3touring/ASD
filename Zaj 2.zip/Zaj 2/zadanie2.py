def shift_negatives(arr):
    #Przesuwa wszystkie liczby ujemne na początek, zachowując kolejność występowania liczb ujemnych oraz nieujemnych.
    #Złożoność czasowa: O(n) – wykonuje dwa przebiegi (jeden dla liczb ujemnych, drugi dla nieujemnych).
    #Złożoność pamięciowa: O(n) – tworzona jest nowa tablica wynikowa.
    # Obliczanie długości tablicy (bez użycia len())
    n = 0
    for _ in arr:
        n += 1

    result = [0] * n  # Inicjalizacja tablicy wynikowej
    index = 0

    # Najpierw umieszczamy liczby ujemne
    i = 0
    while i < n:
        if arr[i] < 0:
            result[index] = arr[i]
            index += 1
        i += 1

    # Następnie umieszczamy liczby nieujemne
    i = 0
    while i < n:
        if arr[i] >= 0:
            result[index] = arr[i]
            index += 1
        i += 1

    return result


def find_missing(arr, n):
    #Znajduje brakującą liczbę w tablicy unikalnych liczb z zakresu 1..n, gdzie tablica ma rozmiar n-1 (brakuje jednej liczby).
    #Złożoność czasowa: O(n) – pojedynczy przebieg przy sumowaniu elementów.
    #Złożoność pamięciowa: O(1) – wykorzystujemy tylko kilka zmiennych pomocniczych.
    # Obliczamy sumę oczekiwaną dla liczb od 1 do n (wzór na ciąg arytmetyczny)
    total = (n * (n + 1)) // 2

    # Odejmujemy kolejne elementy tablicy (sumowanie ręcznie pętlą)
    i = 0
    while i < n - 1:
        total -= arr[i]
        i += 1

    return total


def find_duplicates(arr):
    #Znajduje i zwraca listę duplikatów w danej tablicy.Każdy duplikat pojawia się tylko raz na liście wynikowej.
    #Złożoność czasowa: O(n²) – dla każdego elementu przeszukujemy pozostałą część tablicy.
    #Złożoność pamięciowa: O(n) – w najgorszym przypadku duplikaty mogą pochodzić z większości elementów.
    
    duplicates = []  # Tablica wynikowa

    # Obliczamy ręcznie długość tablicy
    n = 0
    for _ in arr:
        n += 1

    i = 0
    while i < n:
        # Sprawdzamy, czy element arr[i] już wystąpił wcześniej
        already_seen = False
        j = 0
        while j < i:
            if arr[j] == arr[i]:
                already_seen = True
                break
            j += 1
        if already_seen:
            i += 1
            continue

        # Zliczamy wystąpienia arr[i] w dalszej części tablicy
        count = 0
        j = i
        while j < n:
            if arr[j] == arr[i]:
                count += 1
            j += 1

        if count > 1:
            duplicates.append(arr[i])
        i += 1

    return duplicates


def reverse_array(arr):
    #Obraca (odwraca) tablicę in-place – zamienia pierwszy element z ostatnim, drugi z przedostatnim itd.
    #Złożoność czasowa: O(n) – wykonujemy około n/2 zamian.
    #Złożoność pamięciowa: O(1) – działamy w miejscu, nie tworząc dodatkowej tablicy.
    # Obliczamy długość tablicy ręcznie
    n = 0
    for _ in arr:
        n += 1

    i = 0
    while i < n // 2:
        # Zamiana elementu arr[i] z arr[n - i - 1]
        temp = arr[i]
        arr[i] = arr[n - i - 1]
        arr[n - i - 1] = temp
        i += 1

    return arr


def get_int_list(prompt):
    #Pobiera od użytkownika ciąg liczb całkowitych oddzielonych przecinkami. Zwraca listę liczb typu int.
    string = input(prompt)
    parts = string.split(",")
    result = []
    for part in parts:
        # Usuwamy ewentualne białe znaki
        cleaned = ""
        for ch in part:
            if ch != " ":
                cleaned += ch
        try:
            result.append(int(cleaned))
        except ValueError:
            print("Błąd: niepoprawny format liczby.")
            return []
    return result


def main():
    # Zadanie a)
    print("Zadanie a: Przesuń liczby ujemne na początek")
    arr_a = get_int_list("Podaj tablicę liczb całkowitych (oddzielone przecinkami): ")
    if len(arr_a) > 0:
        shifted = shift_negatives(arr_a)
        print("Wynik:", shifted)
    else:
        print("Nieprawidłowe dane wejściowe dla zadania a.")

    # Zadanie b)
    print("\nZadanie b: Znajdź brakującą liczbę w ciągu 1..n")
    arr_b = get_int_list("Podaj tablicę liczb całkowitych (n-1 liczb, oddzielonych przecinkami): ")
    try:
        n_range = int(input("Podaj wartość n (pełny zakres od 1 do n): "))
    except ValueError:
        print("Nieprawidłowa wartość dla n.")
        n_range = 0
    if len(arr_b) == n_range - 1 and n_range > 0:
        missing = find_missing(arr_b, n_range)
        print("Brakująca liczba:", missing)
    else:
        print("Dane wejściowe nie spełniają warunków (oczekiwana liczba elementów = n-1).")

    # Zadanie c)
    print("\nZadanie c: Znajdź duplikaty w tablicy")
    arr_c = get_int_list("Podaj tablicę liczb całkowitych (oddzielonych przecinkami): ")
    if len(arr_c) > 0:
        duplicates = find_duplicates(arr_c)
        print("Duplikaty:", duplicates)
    else:
        print("Nieprawidłowe dane wejściowe dla zadania c.")

    # Zadanie d)
    print("\nZadanie d: Odwróć tablicę")
    arr_d = get_int_list("Podaj tablicę liczb całkowitych (oddzielonych przecinkami): ")
    if len(arr_d) > 0:
        reversed_arr = reverse_array(arr_d)
        print("Odwrócona tablica:", reversed_arr)
    else:
        print("Nieprawidłowe dane wejściowe dla zadania d.")


if __name__ == '__main__':
    main()
    
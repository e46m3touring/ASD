class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

# 1 posort
def find_min_max_sorted(arr):
    steps = 0
    if not arr:
        return None, None, steps
    
    arr.sort()  
    min_val = arr[0]
    max_val = arr[-1]
    
    steps += 2  
    return min_val, max_val, steps

# 2 nieposort
def find_min_max_unsorted(arr):
    steps = 0
    if not arr:
        return None, None, steps
    
    min_val = arr[0]
    max_val = arr[0]
    
    for num in arr[1:]:  
        if num < min_val:
            min_val = num
            steps += 1  
        elif num > max_val:
            max_val = num
            steps += 1  
    
    return min_val, max_val, steps

# 3 drzewo BST
def find_min_max_bst(root):
    steps = 0
    if not root:
        return None, None, steps
    
    min_node = root
    while min_node.left:
        steps += 1
        min_node = min_node.left
    
    max_node = root
    while max_node.right:
        steps += 1
        max_node = max_node.right
    
    return min_node.value, max_node.value, steps

# funk pomoc do tworz drzewa BST
def insert_bst(root, value):
    if not root:
        return TreeNode(value)
    
    if value < root.value:
        root.left = insert_bst(root.left, value)
    else:
        root.right = insert_bst(root.right, value)
    
    return root

# funk pomoc do przetwarz danych wejśc
def get_input_array():
    while True:
        try:
            # wprowadzenie tablicy
            input_str = input("Podaj tablicę (np. [5, 3, 8, 1, 2]): ")
            arr = eval(input_str)  # zamieniamy tekst na listę
            if isinstance(arr, list):
                return arr
            else:
                print("To nie jest poprawna tablica. Spróbuj ponownie.")
        except (SyntaxError, NameError):
            print("Nie udało się przetworzyć danych. Upewnij się, że podałeś poprawną tablicę.")

# funkcja pomoc do wyświet drzewa BST
def print_bst(root, level=0, prefix="Root: "):
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.value))
        if root.left is not None or root.right is not None:
            if root.left:
                print_bst(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_bst(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")

# głów część prog
def main():
    array = get_input_array()
    
    # przetwarz posort
    print("\nPrzetwarzanie tablicy posortowanej...")
    min_val, max_val, steps = find_min_max_sorted(array)
    print(f"Tablica posortowana -> Min: {min_val}, Max: {max_val}, Kroków: {steps}")
    
    # przetwarz nieposort
    print("\nPrzetwarzanie tablicy nieposortowanej...")
    min_val, max_val, steps = find_min_max_unsorted(array)
    print(f"Tablica nieposortowana -> Min: {min_val}, Max: {max_val}, Kroków: {steps}")
    
    # przetwarz drzewa BST
    print("\nPrzetwarzanie drzewa BST...")
    bst_root = None
    for val in array:
        bst_root = insert_bst(bst_root, val)
    
    print("\nStruktura drzewa BST:")
    print_bst(bst_root)
    
    min_val, max_val, steps = find_min_max_bst(bst_root)
    print(f"BST -> Min: {min_val}, Max: {max_val}, Kroków: {steps}")

if __name__ == "__main__":
    main()
    

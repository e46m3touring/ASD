class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False
 
class Trie:
    def __init__(self):
        self.root = TrieNode()
        self.steps = 0  # licz krok
        
    def insert(self, word):
        current = self.root
        for char in word:
            self.steps += 1
            if char not in current.children:
                current.children[char] = TrieNode()
            current = current.children[char]
        current.is_end_of_word = True
        
    def search_by_prefix(self, prefix):
        current = self.root
        for char in prefix:
            self.steps += 1
            if char not in current.children:
                return [], self.steps
            current = current.children[char]
        result = []
        self._find_words_with_prefix(current, prefix, result)
        return result, self.steps
    
    def _find_words_with_prefix(self, node, prefix, result):
        if node.is_end_of_word:
            result.append(prefix)
        for char, child in node.children.items():
            self._find_words_with_prefix(child, prefix + char, result)
 
# funkc do wysz słów zacz od danego pref w tabl
def search_words_in_array(words, prefix):
    steps = 0
    result = []
    seen = set()  # zbiór unik dupl
    for word in words:
        steps += 1
        if word.startswith(prefix) and word not in seen:
            result.append(word)
            seen.add(word)
    return result, steps
 
def main():
    # zbiór sl
    words = [
        "apple", "appetizer", "banana", "bat", "ball", "bake", "batman", "batmanx", "bathe", "car",
        "cat", "catalog", "batman", "dog", "elephant", "ear", "eat", "egg", "earth", "eggplant",
        "fish", "food", "football", "fairy", "family", "friend", "ferry", "forest", "fire", "flame",
        "grape", "goose", "garden", "guitar", "golf", "gate", "great", "glass", "ground", "gala",
        "hat", "horse", "home", "hello", "hobby", "house", "hike", "hill", "heat", "holiday",
        "idea", "iris", "island", "iron", "ice", "insect", "invention", "incredible", "illustration", 
        "jam", "jacket", "jungle", "juice", "jump", "joker", "judge", "jewel", "joke", "job",
        "king", "kite", "kick", "kingdom", "kitchen", "kind", "knight", "knee", "kangaroo", "keyboard",
        "lamp", "lion", "light", "leaf", "love", "laughter", "land", "lake", "lawn", "lamp",
        "mountain", "moon", "mango", "magic", "man", "mighty", "manhole", "market", "marble", "mountain",
        "notebook", "net", "noble", "nature", "night", "ninja", "net", "name", "nurse", "needle",
        "orange", "ocean", "orange", "olive", "office", "octopus", "open", "over", "owl", "objective",
        "pen", "pencil", "pie", "pet", "picture", "peace", "play", "piano", "pocket", "parrot",
        "queen", "quick", "quiet", "question", "queen", "quill", "quake", "quiz", "quilt", "quality",
        "rocket", "rain", "riverside", "radio", "race", "rider", "rescue", "repair", "ranger", "right"
    ]


    words = list(set(words))  # us  dupl
    
    # wybór metod
    choice = input("Wybierz metodę: 'array' (tablica) lub 'trie' (drzewo Trie): ").strip().lower()
    if choice == "array":
        prefix = input("Podaj prefiks do wyszukiwania w tablicy: ")
        result, steps = search_words_in_array(words, prefix)
        print(f"Słowa zaczynające się od prefiksu '{prefix}' w tablicy: {result}")
        print(f"Liczba kroków: {steps}")
    elif choice == "trie":
        
        # tworz drzewo Trie
        trie = Trie()
        for word in words:
            trie.insert(word)
        prefix = input("Podaj prefiks do wyszukiwania w Trie: ")
        result, steps = trie.search_by_prefix(prefix)
        print(f"Słowa zaczynające się od prefiksu '{prefix}' w Trie: {result}")
        print(f"Liczba kroków: {steps}")
    else:
        print("Nieprawidłowy wybór. Proszę wybrać 'array' lub 'trie'.")
 
if __name__ == "__main__":
    main()
    